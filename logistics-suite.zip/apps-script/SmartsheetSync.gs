/************************************************************************
 *  Логистика 2026 — синхронизация Google Sheets → Smartsheet
 *  Режим: полное зеркало (приёмник = точная копия мастера).
 *  Направление: одностороннее (Google = мастер).
 *
 *  КАК УСТАНОВИТЬ (один раз):
 *  1) Открой свою Google-таблицу → меню «Расширения» → «Apps Script».
 *  2) Удали весь код в файле Code.gs и вставь ВЕСЬ этот файл.
 *  3) Впиши свой токен Smartsheet в строку SMARTSHEET_TOKEN ниже
 *     (Account → Personal Settings → API Access → Generate new token).
 *  4) Сохрани (Ctrl/Cmd+S). Обнови вкладку с таблицей.
 *  5) В таблице появится меню «📤 Smartsheet» → «Синхронизация → Smartsheet».
 *     Первый запуск спросит разрешения — разреши (это твой же скрипт).
 ************************************************************************/

// ====== НАСТРОЙКИ ======
const SMARTSHEET_TOKEN = 'ВСТАВЬ_СЮДА_СВОЙ_ТОКЕН';   // <-- единственное, что нужно вписать
const SMARTSHEET_SHEET_ID = '77827511635844';        // лист-приёмник в Smartsheet
const GOOGLE_TAB_NAME = 'Логистика 2026';            // вкладка-мастер в Google

// Соответствие: заголовок в Google  ->  заголовок в Smartsheet (должны совпадать буква-в-букву)
const COLUMN_MAP = {
  'Название проекта'                    : 'Название проекта',
  'Название CAB'                        : 'Название CAB',
  'Компетенции задач для приоритизации' : 'Компетенции задач для приоритизации',
  'Руководитель проекта'                : 'Руководитель проекта',
  'Ресурс'                              : 'Ресурс',
  'Дата начала'                         : 'Дата начала',
  'Срок окончания'                      : 'Срок окончания',
  'Выделено%'                           : 'Выделено%',
  'Загрузка Q1_26'                      : 'Загрузка Q1_26',
  'Загрузка Q2_26'                      : 'Загрузка Q2_26',
  'Загрузка Q3_26'                      : 'Загрузка Q3_26',
  'Загрузка Q4_26'                      : 'Загрузка Q4_26',
  'В реестре 2025'                      : 'В реестре 2025'
};

// Колонки-даты (значение конвертируется в YYYY-MM-DD)
const DATE_COLUMNS = ['Дата начала', 'Срок окончания'];
// Колонка-флажок (пусто -> false, иначе -> true)
const CHECKBOX_COLUMNS = ['В реестре 2025'];

const API = 'https://api.smartsheet.com/2.0';

// ====== МЕНЮ ======
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('📤 Smartsheet')
    .addItem('Синхронизация → Smartsheet', 'syncToSmartsheet')
    .addItem('Проверить подключение', 'testConnection')
    .addToUi();
}

// ====== ПРОВЕРКА ПОДКЛЮЧЕНИЯ ======
function testConnection() {
  try {
    const sheet = smartsheetGet();
    const cols = sheet.columns.map(c => c.title).join(', ');
    SpreadsheetApp.getUi().alert(
      'Подключение OK ✅\n\nЛист Smartsheet: "' + sheet.name + '"\nКолонки приёмника:\n' + cols
    );
  } catch (e) {
    SpreadsheetApp.getUi().alert('Ошибка подключения ❌\n\n' + e.message);
  }
}

// ====== ОСНОВНАЯ СИНХРОНИЗАЦИЯ ======
function syncToSmartsheet() {
  const ui = SpreadsheetApp.getUi();
  try {
    // 1) читаем мастер-лист Google
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const tab = ss.getSheetByName(GOOGLE_TAB_NAME);
    if (!tab) throw new Error('Не найдена вкладка "' + GOOGLE_TAB_NAME + '" в этой таблице.');
    const values = tab.getDataRange().getValues();
    if (values.length < 2) throw new Error('В листе "' + GOOGLE_TAB_NAME + '" нет данных.');

    const gHeaders = values[0].map(h => String(h).trim());
    const dataRows = values.slice(1).filter(r => r.some(c => String(c).trim() !== ''));

    // 2) метаданные Smartsheet (колонки + допустимые значения дропдаунов)
    const sheet = smartsheetGet();
    const colByTitle = {};
    sheet.columns.forEach(c => { colByTitle[c.title] = c; });

    // строим карту: индекс колонки Google -> объект колонки Smartsheet
    const mapping = [];
    Object.keys(COLUMN_MAP).forEach(gTitle => {
      const gIdx = gHeaders.indexOf(gTitle);
      const sCol = colByTitle[COLUMN_MAP[gTitle]];
      if (gIdx === -1) { Logger.log('В Google нет колонки: ' + gTitle); return; }
      if (!sCol)        { Logger.log('В Smartsheet нет колонки: ' + COLUMN_MAP[gTitle]); return; }
      mapping.push({ gIdx: gIdx, gTitle: gTitle, col: sCol });
    });
    if (mapping.length === 0) throw new Error('Ни одна колонка не сопоставилась — проверь названия в COLUMN_MAP.');

    // 3) формируем строки для Smartsheet
    const newRows = dataRows.map(r => {
      const cells = mapping.map(m => buildCell(m, r[m.gIdx]));
      return { toTop: false, cells: cells.filter(Boolean) };
    });

    // 4) полное зеркало: удаляем старые строки приёмника, затем добавляем свежие
    deleteAllRows(sheet);
    addRowsBatched(newRows);

    ui.alert('Готово ✅\n\nОтправлено строк: ' + newRows.length +
             '\nЛист Smartsheet: "' + sheet.name + '"');
  } catch (e) {
    ui.alert('Ошибка синхронизации ❌\n\n' + e.message);
    Logger.log(e);
  }
}

// ====== ПОСТРОЕНИЕ ЯЧЕЙКИ ======
function buildCell(m, rawValue) {
  const cell = { columnId: m.col.id };
  let v = rawValue;

  // флажок
  if (CHECKBOX_COLUMNS.indexOf(m.gTitle) !== -1) {
    cell.value = isTruthy(v);
    return cell;
  }

  // пустое значение -> пустая ячейка
  if (v === '' || v === null || v === undefined) {
    cell.value = '';
    return cell;
  }

  // КОНТАКТ (тип колонки CONTACT_LIST / MULTI_CONTACT_LIST) — напр. «Ресурс»
  if (m.col.type === 'CONTACT_LIST' || m.col.type === 'MULTI_CONTACT_LIST') {
    const s = String(v).trim();
    const emailMatch = s.match(/[^\s,;<]+@[^\s,;>]+/);   // если в тексте есть email
    const contact = {};
    if (emailMatch) {
      contact.email = emailMatch[0];
      const nm = s.replace(emailMatch[0], '').replace(/[<>(),;]/g,'').trim();
      if (nm) contact.name = nm;
    } else {
      // только имя — Smartsheet примет, если колонка не ограничена списком контактов
      contact.name = s;
    }
    cell.objectValue = { objectType: 'CONTACT', name: contact.name || contact.email, email: contact.email };
    // подчищаем undefined-поля (иначе API может ругаться)
    if (!cell.objectValue.email) delete cell.objectValue.email;
    if (!cell.objectValue.name)  cell.objectValue.name = s;
    cell.strict = false;   // не требовать строгого соответствия списку контактов
    return cell;
  }

  // даты -> YYYY-MM-DD
  if (DATE_COLUMNS.indexOf(m.gTitle) !== -1) {
    const iso = toIsoDate(v);
    cell.value = iso || '';
    return cell;
  }

  // дропдаун с ограничением по списку: слать только разрешённые значения, иначе пусто
  if (m.col.options && m.col.options.length) {
    cell.value = (m.col.options.indexOf(String(v).trim()) !== -1) ? String(v).trim() : '';
    return cell;
  }

  // число или текст
  if (typeof v === 'number') { cell.value = v; return cell; }
  const num = parseLocaleNumber(v);
  cell.value = (num !== null) ? num : String(v);
  return cell;
}

// ====== ХЕЛПЕРЫ ЗНАЧЕНИЙ ======
function isTruthy(v) {
  if (v === true) return true;
  const s = String(v).trim().toLowerCase();
  return ['true','истина','да','1','x','✓','y','yes'].indexOf(s) !== -1;
}
function toIsoDate(v) {
  if (v instanceof Date && !isNaN(v)) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  const s = String(v).trim();
  let m = s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{2,4})$/);
  if (m) {
    let d = m[1], mo = m[2], y = m[3];
    if (y.length === 2) y = '20' + y;
    return y + '-' + ('0'+mo).slice(-2) + '-' + ('0'+d).slice(-2);
  }
  m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) return m[1] + '-' + ('0'+m[2]).slice(-2) + '-' + ('0'+m[3]).slice(-2);
  return null;
}
function parseLocaleNumber(v) {
  let s = String(v).trim();
  if (s === '') return null;
  const pct = s.indexOf('%') !== -1;
  s = s.replace('%','').replace(/\s/g,'').replace(',', '.');
  if (!/^-?\d*\.?\d+$/.test(s)) return null;
  let n = parseFloat(s);
  if (isNaN(n)) return null;
  return pct ? n/100 : n;
}

// ====== SMARTSHEET API ======
function smartsheetHeaders() {
  return { 'Authorization': 'Bearer ' + SMARTSHEET_TOKEN, 'Content-Type': 'application/json' };
}
function smartsheetGet() {
  const resp = UrlFetchApp.fetch(API + '/sheets/' + SMARTSHEET_SHEET_ID, {
    method: 'get', headers: smartsheetHeaders(), muteHttpExceptions: true
  });
  const code = resp.getResponseCode();
  if (code !== 200) throw new Error('GET sheet: HTTP ' + code + ' — ' + resp.getContentText());
  return JSON.parse(resp.getContentText());
}
function deleteAllRows(sheet) {
  const ids = (sheet.rows || []).map(r => r.id);
  if (!ids.length) return;
  // удаляем пачками по 300 (ограничение длины URL)
  for (let i = 0; i < ids.length; i += 300) {
    const chunk = ids.slice(i, i + 300);
    const resp = UrlFetchApp.fetch(
      API + '/sheets/' + SMARTSHEET_SHEET_ID + '/rows?ids=' + chunk.join(',') + '&ignoreRowsNotFound=true',
      { method: 'delete', headers: smartsheetHeaders(), muteHttpExceptions: true }
    );
    if (resp.getResponseCode() !== 200)
      throw new Error('DELETE rows: HTTP ' + resp.getResponseCode() + ' — ' + resp.getContentText());
  }
}
function addRowsBatched(rows) {
  // добавляем пачками по 400 строк (лимит API)
  for (let i = 0; i < rows.length; i += 400) {
    const chunk = rows.slice(i, i + 400);
    const resp = UrlFetchApp.fetch(API + '/sheets/' + SMARTSHEET_SHEET_ID + '/rows', {
      method: 'post', headers: smartsheetHeaders(),
      payload: JSON.stringify(chunk), muteHttpExceptions: true
    });
    if (resp.getResponseCode() !== 200)
      throw new Error('POST rows: HTTP ' + resp.getResponseCode() + ' — ' + resp.getContentText());
  }
}
